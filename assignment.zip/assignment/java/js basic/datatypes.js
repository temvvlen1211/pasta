// // 5. Datatypes.js нэртэй файл үүсгэх, typeof ашиглан өөр, өөр, төрлийн утгуудыг шалгах, number, string, boolean, undefined,  null гэх мэт
// let message = 120;
// console.log(typeof message);
// message = false;
// console.log(typeof message);
// message = "hi";
// console.log(typeof message);
// message = null;
// console.log(message);

// let test;
// console.log(typeof test);
// test = null;
// console.log(test);

// // 6. Утга оноогоогүй хувьсагч зарлах
// // let = "";
// // console.log();
// // 7. Утга оноосон хувьсагч зарлах
// let comments = 120;
// console.log(comments);
// // 8. Олон мөрөнд First name, last name, marital status, country, age гэсэн нэртэй хувьсагч зарлах
// let Firstname = "temuulen",
//   lastname = "bayrsaihan",
//   maritalstatus = "single",
//   country = "Ub",
//   age = "18";
// console.log(Firstname);
// console.log(lastname);
// console.log(maritalstatus);
// console.log(country);
// console.log(age);
// // 9. Нэг мөрөнд First name, last name, marital status, country, age гэсэн нэртэй хувьсагч зарлах
// let Firstnames = "temuulen";
// console.log(Firstnames);
// let lastnames = "bayrsaihan";
// console.log(lastnames);
// let maritalstatuss = "single";
// console.log(maritalstatuss);
// let countrys = "Ub";
// console.log(countrys);
// let ages = "18";
// console.log(ages);
// //10. MyAge, yourAge нэртэй хувьсагч зарлан эхний утгыг оноох
// let MyAge = "18",
//   yourAge = "21";
// console.log(MyAge);
// console.log(yourAge);
// // 11. Гурвалжингийн периметрийг олох
// let a, b, c;
// a = 10;
// b = 5;
// c = 15;
// console.log(a + b + c);
// 11. Тойргийн талбайг олох
// let a, r;
// r = prompt("too oriilna uu ", "");
// a = 3.14 * r ** 2;
// alert("Toirgiin talbai: " + a);
// m = y2-y1/x2-x1 хариуг олох
// let m, x1, x2, y1, y2;
// m = y2 - y1 / x2 - x1;
// y1 = 5;
// y2 = 8;
// x1 = 4;
// x2 = 7;
// console.log(m);
// 13. 15 Gegabyte нь хэдэн биттэй тэнцүү вэ ?
// let m, g;
// g = prompt("hedn gigabyte ve", "");
// m = g * 1024;
// alert(m + "megabyte");
// 14. 15 МB дата 3 секундэд манай интернэт онлайнаар татаж чаддаг бол түүнийг BIT Rate-ийг олно уу.
// let n, s, mb;
// n = prompt("hedn MB ve", "");
// s = 3;
// mb = n * 3;
// alert(mb);
// 15. side1, side2, side3 гэсэн хувьсагчдад гурвалжны гурван талыг онооно. Ийнхүү гурван тал өгөдсөн байхад үед гурвалжны талбайг ол.
let side1, side2, side3;
side1 = 1;
side2 = 2;
side3 = 4;
