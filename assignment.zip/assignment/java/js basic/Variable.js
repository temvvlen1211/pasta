// 1 Comments can make code readable
// 2 Javascript lesson begin
/*
     3 Comments can make code readable
 */
// 4. Variable.js нэртэй файл үүсгэх, number, string, boolean, undefined, null зэрэг утгуудыг өгөх
let message = 120;
message = false;
message = "hi";
message = null;

let test;
test = null;

// 23. Variable.js нэртэй файл үүсгэх, number, string, boolean, undefined, null зэрэг утгуудыг өгөх
// Доорх Baby Shark дууны үгийг хамгийн ихдээ 12 хувьсагч ашиглан орлуулан бичээд console дээр дарааллуулан хэвлэж харуулна уу.
let Babyshark = "Baby shark ";
let Mommyshark = "Mommy shark";
let Daddyshark = "Daddy shark";
let Grandmashark = "Grandma shark";
let Grandpashark = "Grandpa shark";
let Letsgohunt = "Let's go hunt";
let Runaway = "Run away";
let Safeatlast = "Safe at last";
let Itstheend = "It's the end";
let doo = "doo-doo ";
console.log(Babyshark + "," + doo + "," + doo);
console.log(Babyshark + "," + doo + "," + doo);
console.log(Babyshark + "," + doo + "," + doo);
console.log(Babyshark);
console.log(Mommyshark + "," + doo + "," + doo);
console.log(Mommyshark + "," + doo + "," + doo);
console.log(Mommyshark + "," + doo + "," + doo);
console.log(Mommyshark);
console.log(Daddyshark + "," + doo + "," + doo);
console.log(Daddyshark + "," + doo + "," + doo);
console.log(Daddyshark + "," + doo + "," + doo);
console.log(Daddyshark);
console.log(Grandmashark + "," + doo + "," + doo);
console.log(Grandmashark + "," + doo + "," + doo);
console.log(Grandmashark + "," + doo + "," + doo);
console.log(Grandmashark);
console.log(Grandpashark + "," + doo + "," + doo);
console.log(Grandpashark + "," + doo + "," + doo);
console.log(Grandpashark + "," + doo + "," + doo);
console.log(Grandpashark);
console.log(Letsgohunt + "," + doo + "," + doo);
console.log(Letsgohunt + "," + doo + "," + doo);
console.log(Letsgohunt + "," + doo + "," + doo);
console.log(Letsgohunt);
console.log(Runaway + "," + doo + "," + doo);
console.log(Runaway + "," + doo + "," + doo);
console.log(Runaway + "," + doo + "," + doo);
console.log(Runaway);
console.log(Safeatlast + "," + doo + "," + doo);
console.log(Safeatlast + "," + doo + "," + doo);
console.log(Safeatlast + "," + doo + "," + doo);
console.log(Safeatlast);
console.log(Itstheend + "," + doo + "," + doo);
console.log(Itstheend + "," + doo + "," + doo);
console.log(Itstheend + "," + doo + "," + doo);
console.log(Itstheend);
